# `BaseEmbedder`

::: bertopic.backend._base.BaseEmbedder
