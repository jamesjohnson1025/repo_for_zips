# `Documents`

::: bertopic.plotting._documents.visualize_documents
