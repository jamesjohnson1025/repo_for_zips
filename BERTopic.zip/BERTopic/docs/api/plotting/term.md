# `Term Score Decline`

::: bertopic.plotting._term_rank.visualize_term_rank
