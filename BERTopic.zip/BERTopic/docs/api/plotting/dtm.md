# `DTM`

::: bertopic.plotting._topics_over_time.visualize_topics_over_time
