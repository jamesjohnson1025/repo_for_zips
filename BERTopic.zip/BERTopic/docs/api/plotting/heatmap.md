# `Heatmap`

::: bertopic.plotting._heatmap.visualize_heatmap
