# `Maximal Marginal Relevance`

::: bertopic._mmr.mmr
