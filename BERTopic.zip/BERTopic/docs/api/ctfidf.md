# `c-TF-IDF`

::: bertopic.vectorizers._ctfidf.CTfidfTransformer
