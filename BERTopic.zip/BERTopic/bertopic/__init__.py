from bertopic._bertopic import BERTopic

__version__ = "0.11.0"

__all__ = [
    "BERTopic",
]
